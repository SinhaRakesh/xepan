<?php

class page_simplebillingApp_page_install extends page_componentBase_page_install {
	
}
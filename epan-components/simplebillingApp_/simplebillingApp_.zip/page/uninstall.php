<?php

class page_simplebillingApp_page_uninstall extends page_componentBase_page_uninstall{} 
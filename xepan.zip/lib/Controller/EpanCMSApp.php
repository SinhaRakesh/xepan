<?php

class Controller_EpanCMSApp extends AbstractController {

	function frontEnd() {}

	/**
	 * This function sets website_requested and page_requested
	 * properties in api from HTTP_REFERRER from subdomain
	 */
	function setWebsiteFromReferrer() {}

	function addAliasesPage(){}

	function ownerComponentRepository(){}

}
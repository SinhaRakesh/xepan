<?php

class page_branch_main extends Page {
	function init(){
		parent::init();

	}
}
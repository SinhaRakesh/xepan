<?php
class page_epan extends page_index {}
<?php

namespace slideshowModule;

class View_Tools_SlideShowTool extends \editingToolbar\View_Tool {
	public $title = 'SlideShow';
	public $class='View_SlideShow';
	
}
<?php

namespace slideshowModule;

class View_SlideShow extends \componentBase\View_Component{
	public $is_sortable = false;

	
}
<?php

namespace titleElement;

class View_Tools_TitleTool extends \editingToolbar\View_Tool {
	public $title = 'Title';
	public $class='View_Title';
	
}
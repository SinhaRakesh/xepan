<?php

namespace userLoginElement;

class View_Tools_UserLoginElementTool extends \editingToolbar\View_Tool {
	public $namespace = __NAMESPACE__;
	public $title = 'User Login';
	public $class='View_UserLogin';
	public $component_type='UserLogin';
	
}
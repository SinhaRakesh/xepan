<?php

namespace visitorCounterApp;

class View_Tools_VisitorCounterTool extends \editingToolbar\View_Tool {
	public $namespace = __NAMESPACE__;
	public $title = 'Visitor Counter';
	public $class='View_VisitorCounter';
	public $component_type='VisitorCounter';
	
}
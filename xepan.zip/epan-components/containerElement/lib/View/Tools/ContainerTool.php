<?php

namespace containerElement;

class View_Tools_ContainerTool extends \editingToolbar\View_Tool {
	public $title = 'Container';
	public $class='View_Container';
}
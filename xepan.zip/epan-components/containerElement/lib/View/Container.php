<?php

namespace containerElement;

class View_Container extends \componentBase\View_Component{
	public $is_sortable = true;
}
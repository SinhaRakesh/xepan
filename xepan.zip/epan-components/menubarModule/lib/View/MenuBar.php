<?php

namespace menubarModule;

class View_MenuBar extends \componentBase\View_Component{
	public $is_sortable = false;
	
	
}
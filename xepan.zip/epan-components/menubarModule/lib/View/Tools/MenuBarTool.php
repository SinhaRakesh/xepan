<?php

namespace menubarModule;

class View_Tools_MenuBarTool extends \editingToolbar\View_Tool {
	public $title = 'MenuBar';
	public $class='View_MenuBar';
	
}
<?php

namespace simpleImageGallaryApp;


class View_ImageGallary_Options extends \componentBase\View_Options{

	public $namespace='simpleImageGallaryApp';
	public $component_type='SimpleImageGallaryApp';

}
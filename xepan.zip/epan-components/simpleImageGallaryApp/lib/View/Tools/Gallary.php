<?php

namespace simpleImageGallaryApp;

class View_Tools_Gallary extends \editingToolbar\View_Tool {
	public $namespace = __NAMESPACE__;
	public $title = 'Image Galary';
	public $class='View_ImageGallary';
	public $component_type='SimpleImageGallaryApp';
	
}
<?php

namespace socialshareModule;

class View_Tools_SocialShareTool extends \editingToolbar\View_Tool {
	public $title = 'SocialShare';
	public $class='View_SocialShare';
	
}
<?php

namespace socialshareModule;

class View_SocialShare extends \componentBase\View_Component{
	public $is_sortable = false;

	
}
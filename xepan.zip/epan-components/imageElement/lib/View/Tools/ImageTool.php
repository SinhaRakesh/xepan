<?php

namespace imageElement;

class View_Tools_ImageTool extends \editingToolbar\View_Tool {
	public $title = 'Image';
	public $class='View_Image';
	
}
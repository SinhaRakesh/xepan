<?php

namespace enquiryformModule;

class View_Tools_EnquiryFormTool extends \editingToolbar\View_Tool {
	public $title = 'EnquiryForm';
	public $class='View_EnquiryForm';

}
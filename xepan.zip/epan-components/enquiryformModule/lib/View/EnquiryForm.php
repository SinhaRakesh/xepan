<?php

namespace enquiryformModule;

class View_EnquiryForm extends \componentBase\View_Component{
	public $is_sortable = false;
}
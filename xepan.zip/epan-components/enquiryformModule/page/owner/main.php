<?php

class page_enquiryformModule_page_owner_main extends page_componentBase_page_owner_main {
	function init(){
		parent::init();

	}
}
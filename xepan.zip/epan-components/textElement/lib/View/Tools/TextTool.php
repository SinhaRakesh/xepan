<?php

namespace textElement;

class View_Tools_TextTool extends \editingToolbar\View_Tool {
	public $title = 'Text';
	public $class='View_Text';
	
}
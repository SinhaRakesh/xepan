<?php

namespace textElement;

class View_Text extends \componentBase\View_Component{
	public $is_sortable = false;
	
	
}
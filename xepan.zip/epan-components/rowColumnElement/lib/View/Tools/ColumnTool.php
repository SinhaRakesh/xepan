<?php

namespace rowColumnElement;

class View_Tools_ColumnTool extends \editingToolbar\View_Tool {
	public $title = 'Column';
	public $class='View_Column';

}
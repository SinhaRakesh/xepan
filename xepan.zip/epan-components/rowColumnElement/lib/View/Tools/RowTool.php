<?php

namespace rowColumnElement;

class View_Tools_RowTool extends \editingToolbar\View_Tool {
	public $title = 'Row';
	public $class='View_Row'; // Which component to be rendered as on Drop by this Tool
	
}
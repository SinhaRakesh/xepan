<?php

namespace rowColumnElement;

class View_Column extends \componentBase\View_Component{
	public $is_sortable = true;
	
	
}
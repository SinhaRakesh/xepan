<?php

namespace rowColumnElement;

class View_Row extends \componentBase\View_Component{
	public $is_sortable = true;
	public $items_allowed='.col-md-[*]';
	
	
}